import { AfterContentInit, Component, Input } from '@angular/core';
import { AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-field',
  templateUrl: './field.component.html',
  styles: [
  ]
})
export class FieldComponent implements AfterContentInit {
  @Input() label: string;  // Libellé du champ
  @Input() control: AbstractControl;  // Instance de champ de formulaire Angular

  ngAfterContentInit() {

  }

}

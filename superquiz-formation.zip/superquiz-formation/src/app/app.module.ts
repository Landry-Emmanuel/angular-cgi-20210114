import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { QuizModule } from './quiz/quiz.module';
import { LoginComponent } from './common/login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { AuthGuard } from './auth.guard';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    HomeComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    QuizModule,   // active le module Quiz
    RouterModule.forRoot([
      { path: 'home', component: HomeComponent },
      { path: 'login', component: LoginComponent },
      { path: '', redirectTo: 'home', pathMatch: 'full' },
      {
        path: 'admin',
        loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule),
        // canActivate: [ AuthGuard ],
        canLoad: [ AuthGuard ],
        canActivateChild: [],
      }
    ]),
    HttpClientModule,   // Active le service HttpClient
  ],
  providers: [
    { provide: 'JSON_SERVER_URL', useValue: 'http://localhost:3004' },
    { provide: 'SETTINGS', useValue: environment },
  ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }

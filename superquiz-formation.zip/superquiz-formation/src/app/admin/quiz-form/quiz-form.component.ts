import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Quiz } from 'src/app/models';
import { QuizService } from 'src/app/quiz/quiz.service';

@Component({
  selector: 'app-quiz-form',
  templateUrl: './quiz-form.component.html'
})
export class QuizFormComponent implements OnInit {
  quizForm: FormGroup;
  currentQuiz: Quiz;

  constructor(private fb: FormBuilder,
              private route: ActivatedRoute,
              private router: Router,
              private quizService: QuizService) { }

  ngOnInit(): void {
    this.quizForm = this.fb.group({
      title: ['', [Validators.required, Validators.minLength(5)]],
      description: ['', Validators.required],
      canRetryQuestion: [],
    });

    // this.router.events.subscribe

    // Récupère le param quizId dans l'URL.
    const quizId = +this.route.snapshot.paramMap.get('quizId');

    // Si quizId, charge le quiz correspond et "pousse" les valeurs dans le form.
    if (quizId) {
      this.quizService.loadQuiz(quizId)
        .subscribe(quiz => {
          this.currentQuiz = quiz;
          this.quizForm.patchValue(this.currentQuiz);
        });
    }
    // Si pas de quizId, initialise un quiz vierge.
    else {
      this.currentQuiz = new Quiz();
    }
  }

  saveQuiz() {
    // Màj le quiz en cours d'édition avec les valeurs issues du form.
    const quizToSave: Quiz = Object.assign(this.currentQuiz, this.quizForm.value);
    // Puis sauvegarde le quiz et redirige sur la liste des quizs.
    this.quizService.saveQuiz(quizToSave)
      .subscribe(() => this.router.navigate(['/admin/quiz']));
  }

}

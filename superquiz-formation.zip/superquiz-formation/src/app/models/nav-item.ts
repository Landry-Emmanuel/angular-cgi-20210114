/**
 * @file
 * An item in the navbar.
 */
export interface NavItem {
  text: string;
  path: string;
}

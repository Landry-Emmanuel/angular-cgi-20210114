/**
 * @file
 * A user logged into the application.
 */

// Créer la classe User ici.
export class User {
  name: string;
  email: string;
  photo: string;
  active: boolean;

  // public options: {
  //   name: string;
  //   email: string;
  //   photo?: string;
  //   active?: boolean;
  // }

  constructor(options: {
    name: string;
    email: string;
    photo?: string;
    active?: boolean;
  }) {
    // this.options = options;
    this.name = options.name;
    this.email = options.email;
    this.photo = options.photo || '';
    this.active = options.active !== undefined ? options.active : true;
  }
}

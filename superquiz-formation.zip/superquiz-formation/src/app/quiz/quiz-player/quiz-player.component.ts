import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Answer, AnswersState, Question, Quiz } from '../../models';
import { QuizStateManager } from '../quiz-state-manager.service';
import { QuizService } from '../quiz.service';

@Component({
  selector: 'app-quiz-player',
  templateUrl: './quiz-player.component.html',
  styles: [
  ]
})
export class QuizPlayerComponent implements OnInit {
  currentQuiz: Quiz;  // quiz en cours
  currentQuestion: Question;  // question en cours
  currentAnswer: Answer;  // réponse en cours
  currentAnswers: AnswersState;  // toutes les réponses soumises par l'utilisateur

  isStarted = false;

  constructor(private route: ActivatedRoute,
              private quizService: QuizService,
              private qsm: QuizStateManager) { }

  ngOnInit(): void {
    const quizId = +this.route.snapshot.paramMap.get('quizId');
    this.quizService.loadQuiz(quizId)
      .subscribe(quiz => {
        this.currentQuiz = quiz;
        this.qsm.setQuiz(this.currentQuiz);
        this.currentAnswers = this.qsm.getAllAnswers();
      })
  }

  startQuiz() {
    this.isStarted = true;
    const { question, answer } = this.qsm.getFirstQA();
    this.currentQuestion = question;
    this.currentAnswer = answer;
  }

  gotoPreviousQuestion() {
    const { question, answer } = this.qsm.getPreviousQA();
    this.currentQuestion = question;
    this.currentAnswer = answer;
  }

  gotoNextQuestion() {
    const { question, answer } = this.qsm.getNextQA();
    this.currentQuestion = question;
    this.currentAnswer = answer;
  }

  saveAnswer(answer: Answer) {
    this.qsm.saveAnswer(answer);
  }

}

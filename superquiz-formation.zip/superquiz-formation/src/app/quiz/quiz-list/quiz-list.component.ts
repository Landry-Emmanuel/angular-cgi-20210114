import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Quiz } from '../../models';
import { QuizService } from '../quiz.service';

@Component({
  selector: 'app-quiz-list',
  templateUrl: './quiz-list.component.html',
  styles: [
  ]
})
export class QuizListComponent implements OnInit {
  quizList$: Observable<Quiz[]>;

  constructor(private quizService: QuizService) { }

  ngOnInit(): void {
    this.quizList$ = this.quizService.loadQuizzes();
  }

}

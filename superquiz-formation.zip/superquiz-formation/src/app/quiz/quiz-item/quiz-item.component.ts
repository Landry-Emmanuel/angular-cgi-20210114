import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Quiz } from '../../models';

@Component({
  selector: 'app-quiz-item',
  templateUrl: './quiz-item.component.html',
  styles: [
  ]
})
export class QuizItemComponent implements OnInit, OnDestroy {
  @Input() quiz: Quiz;

  constructor() {
    // console.log(`quiz`, this.quiz);  // UNDEFINED
  }

  ngOnInit(): void {
    // console.log(`quiz`, this.quiz);  // QUIZ
  }

  ngOnDestroy(): void {

  }

}

import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';

import { Observable, of } from 'rxjs';
import { catchError, delay, map } from 'rxjs/operators';

import { Quiz, QuizSubmission } from '../models';

@Injectable({
  providedIn: 'root'
})
export class QuizService {
  // private baseUrl = 'http://localhost:3004';

  constructor(private http: HttpClient,
              @Inject('SETTINGS') private settings: any) { }

  /**
   * ===========================
   * CRUD operations on QUIZZES.
   * ===========================
   */

  /**
   * Load the list of all quizzes.
   */
  loadQuizzes(): Observable<Quiz[]> {
    return this.http.get<any[]>(`${this.settings.jsonServerUrl}/quizzes`)
      // Re-hydrate
      .pipe(
        map(quizArray => quizArray.map(quizData => new Quiz(quizData)))
      );
  }

  /**
   * Load the given quiz ALONG WITH its questions.
   */
  loadQuiz(quizId: number): Observable<Quiz> {
    return this.http.get(`${this.settings.jsonServerUrl}/quizzes/${quizId}`)
      .pipe(
        map(quizData => new Quiz(quizData)),
        catchError(this.muteRequestError),
      )
      ;
  }

  /**
   * Save the given quiz (INSERT or UPDATE).
   */
  saveQuiz(quiz: Quiz): Observable<any> {
    const url = `${this.settings.jsonServerUrl}/quizzes` + (quiz.id ? `/${quiz.id}` : '');
    const method = quiz.id ? 'put' : 'post';
    return this.http.request(method, url, {body: quiz});
  }

  /**
   * Delete the given quiz.
   */
  deleteQuiz(quizId: number): Observable<any> {
    return this.http.delete(`${this.settings.jsonServerUrl}/quizzes/${quizId}`);
  }

  /**
   * ===============================
   * CRUD operations on SUBMISSIONS.
   * ===============================
   */

  /**
   * Load a quiz submission.
   */
  loadQuizSubmission(submissionId: number): Observable<QuizSubmission> {
    return this.http.get(`${this.settings.jsonServerUrl}/submissions/${submissionId}`)
      // Re-hydrate
      .pipe(
        map((submissionData: any) => new QuizSubmission(submissionData))
      );
  }

  /**
   * Save a quiz submission.
   */
  saveQuizSubmission(submission: QuizSubmission): Observable<any> {
    return this.http.post(`${this.settings.jsonServerUrl}/submissions`, submission);
      // .delay(2000);  // Only to show off the spinner.
  }

  //
  //
  //

  // Catch (and rethrow).
  private muteRequestError(err: any): Observable<any> {
    const errorMsg = `${err.statusText} (${err.status})`;
    return of(null);
    // return Observable.throw(new Error(errorMsg));
  }
}

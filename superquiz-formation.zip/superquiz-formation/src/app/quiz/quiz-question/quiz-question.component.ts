import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';

import { Question, Answer, Choice } from '../../models';

@Component({
  selector: 'app-quiz-question',
  templateUrl: './quiz-question.component.html',
  styles: [
    `.disabled { cursor: not-allowed; }`
  ]
})
export class QuizQuestionComponent implements OnInit, OnChanges {
  @Input() bgColor: string = 'white';
  @Input() question: Question;  // Question en cours
  @Input() answer: Answer;  // Réponse en cours

  @Output() submit = new EventEmitter<Answer>();

  isSubmitted: boolean;
  submitLabel: string;
  submitClass: string;

  constructor() { }

  ngOnInit(): void {
    this.isSubmitted = this.answer.isAnswered();
    this.refreshButton();
  }

  ngOnChanges(): void {
    this.isSubmitted = this.answer.isAnswered();
    this.refreshButton();
  }

  clickChoice(choice: Choice): void {
    if (this.isSubmitted) { return; }

    if (this.answer.hasChoice(choice)) {
      this.answer.removeChoice(choice);
    } else {
      this.answer.addChoice(choice);
    }
  }

  submitAnswer() {
    this.isSubmitted = true;
    this.refreshButton();
    this.submit.emit(this.answer);
  }

  private refreshButton() {
    if (!this.isSubmitted) {
      this.submitLabel = 'Soumettre';
      this.submitClass = 'btn-primary';  // bleu
    } else {
      if (this.answer.isCorrect) {
        this.submitLabel = 'CORRECT';
        this.submitClass = 'btn-success';  // vert
      } else {
        this.submitLabel = 'INCORRECT';
        this.submitClass = 'btn-danger';   // rouge
      }
    }
  }

  // Charge une nouvelle question et une nouvelle réponse.
  gotoNextQuestionTEMP(): void {
    this.question = new Question({
      id: 35,
      title: 'Angular est vraiment trop canon.',
      choices: [
        { text: 'Vrai', isCorrect: true },
        { text: 'Faux'}
      ],
      explanation: 'À ce stade, comment ne pas en être persuadé ? 😝'
    });
    this.answer = new Answer({
      questionId: 35,
      multipleChoicesAllowed: false
    });

    // Ne pas oublier
    this.isSubmitted = this.answer.isAnswered();
    this.refreshButton();
  }
}

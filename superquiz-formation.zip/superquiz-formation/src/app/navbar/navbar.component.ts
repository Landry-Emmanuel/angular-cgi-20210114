import { Component, OnInit } from '@angular/core';
import { NavItem, User } from '../models';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styles: [
  ]
})
export class NavbarComponent implements OnInit {
  logo = '/assets/logo_superquiz.png';
  user = new User({ name: 'Bob', email: 'bob@bob.com' });
  navItems: NavItem[] = [
    { text: 'Accueil', path: 'home' },
    { text: 'Quizs', path: 'quizzes' },
    { text: 'Admin', path: 'admin' },
    { text: 'Login', path: 'login' },
  ]

  constructor() { }

  ngOnInit(): void {
  }

}

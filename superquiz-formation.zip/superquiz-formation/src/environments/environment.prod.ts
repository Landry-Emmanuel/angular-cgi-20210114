export const environment = {
  production: true,
  jsonServerUrl: 'https://api.monsite.com'
};

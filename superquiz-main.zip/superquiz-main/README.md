# SuperQuiz

Application développée pendant la formation Angular.

Cette appli a été générée avec [Angular CLI](https://github.com/angular/angular-cli) version 11.0.2. Quelques personnalisations ont ensuite été effectuées pour la formation.
